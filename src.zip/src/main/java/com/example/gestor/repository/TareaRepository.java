package com.example.gestor.repository;

import com.example.gestor.model.Tarea;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class TareaRepository {

    private final List<Tarea> tareas = new ArrayList<>();
    private int siguienteId = 1;

    // Implementa aquí los cinco métodos:
    // findAll()
    // findById(int id)
    // save(Tarea tarea)
    // deleteById(int id)
    // existsById(int id)
}